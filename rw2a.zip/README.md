# rw2a
 RW2A MCFX: Species (teams) to play as and more! A mcfunction datapack for Minecraft Java version 1.20.2

Current Teams v0:
	Shade: Shadow Armor(in dark), Coalcaine(coal, charcoal), Bad Touch(consume+melee), Hard Light(in light)
	Trent: Photosynthesis(in light), Blossom Armor(flowers), Crippling Roots(consume+melee||ranged), Fear of Fire(fire,lava)
